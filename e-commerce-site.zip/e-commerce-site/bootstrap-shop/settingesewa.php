<?php 

    $epay_url = "https://uat.esewa.com.np/epay/main";
    $pid = "Bootshop032";
?>