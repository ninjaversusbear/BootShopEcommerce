<?php 

    session_start();

    session_unset();

    session_destroy();

    header("location: http://localhost/e-commerce-site/bootstrap-shop/index.php");

?>