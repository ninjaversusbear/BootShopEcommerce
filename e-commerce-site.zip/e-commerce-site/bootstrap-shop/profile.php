<?php 
    include "./DB_CON/config.php";

    session_start();

    $p_uid = $_SESSION['id'];

    $sql = "SELECT * FROM `reg-users` WHERE id = '{$p_uid}'";
    $result = mysqli_query($conn, $sql) or die("ERROR : MySQL Query Failed to execute!!");

    if(mysqli_num_rows($result) > 0){
?>
<!DOCTYPE html>
<html lang="en">
<?php while($row = mysqli_fetch_assoc($result)){ ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $row['first_name']; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        * {
            margin: 0;
            padding: 0
        }

        body {
            background-color: #000
        }

        .card {
            width: 350px;
            background-color: #efefef;
            border: none;
            cursor: pointer;
            transition: all 0.5s;
        }

        .image img {
            transition: all 0.5s
        }

        .card:hover .image img {
            transform: scale(1.5)
        }

        .btn {
            height: 140px;
            width: 140px;
            border-radius: 50%
        }

        .name {
            font-size: 22px;
            font-weight: bold
        }

        .idd {
            font-size: 14px;
            font-weight: 600
        }

        .idd1 {
            font-size: 12px
        }

        .number {
            font-size: 22px;
            font-weight: bold
        }

        .follow {
            font-size: 12px;
            font-weight: 500;
            color: #444444
        }

        .btn1 {
            height: 40px;
            width: 150px;
            border: none;
            background-color: #000;
            color: #aeaeae;
            font-size: 15px
        }

        .text span {
            font-size: 13px;
            color: #545454;
            font-weight: 500
        }

        .icons i {
            font-size: 19px
        }

        hr .new1 {
            border: 1px solid
        }

        .join {
            font-size: 14px;
            color: #a0a0a0;
            font-weight: bold
        }

        .date {
            background-color: #ccc
        }
    </style>
</head>

<body>
    <div class="container mt-4 mb-4 p-3 d-flex justify-content-center">
        <?php 
        
        ?>
        <div class="card p-4">
            <div class=" image d-flex flex-column justify-content-center align-items-center"> <button class="btn btn-secondary"> <img style="object-fit:cover; border-radius:120px;" src="./uploaded-images/<?php echo $row['profile_picture']; ?>" height="100" width="100" /></button> <span class="name mt-3"><?php echo $row['first_name'].' '. $row['last_name']; ?></span> <span class="idd"><?php echo $row['email']; ?></span>
                <div class="d-flex flex-row justify-content-center align-items-center gap-2"> <span class="idd1"><?php echo $row['dob']; ?></span> </div>
                <div class="d-flex flex-row justify-content-center align-items-center mt-3"> <span class="number">1069 <span class="follow">Followers</span></span> </div>
                <div class="text mt-3"> <span><?php echo $row['additional_information']; ?></span> </div>
                <div class=" px-2 rounded mt-4 date "> <span class="join">Joined <?php echo $row['reg_date']; ?></span> </div><br>
                <div class=" d-flex mt-2"> <button class="btn1 btn-dark">Edit Profile</button> </div>
                <div class=" d-flex mt-2"><a href="index.php"><button class="btn1 btn-dark">Back</button></a></div>
            </div>
        </div>
    </div>
</body>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<?php }?>
</html>
<?php }?>