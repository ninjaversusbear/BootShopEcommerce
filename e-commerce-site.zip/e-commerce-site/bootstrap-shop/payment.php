<?php
include "settingesewa.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Esewa - Payment</title>

<body>
    
    <div class="container text-center mt-5">
        <div class="row">
            <div class="col">

            </div>
            <div class="col-6">
                <h1><i>Choose Payment Options</i></h1>
            </div>
            <div class="col">

            </div>
        </div>
    </div>

    <div class="container text-center" style="margin-top:150px;">
        <div class="row">
            <div class="col">
            <img src="./themes/images/fonepay.png" style="width: 100%;" alt="">
            <form action="#" class="mt-5">
            <input class="btn btn-success w-100" value="Pay With fonePay" type="submit" disabled>
            </form>
            </div>
            <div class="col">
                <?php
                include "./DB_CON/config.php";

                $id = $_GET['id'];
                $sql = "SELECT * FROM `product_data` WHERE id = '{$id}'";

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                ?>
                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                        <form action="<?php echo $epay_url; ?>" target="_blank" method="POST">
                            <input value="100" name="tAmt" type="hidden">
                            <input value="90" name="amt" type="hidden">
                            <input value="5" name="txAmt" type="hidden">          
                            <input value="2" name="psc" type="hidden">
                            <input value="3" name="pdc" type="hidden">
                            <input value="EPAYTEST" name="scd" type="hidden">
                            <input value="<?php echo $pid; ?>" name="pid" type="hidden">
                            <input value="http://merchant.com.np/page/esewa_payment_success?q=su" type="hidden" name="su">
                            <input value="http://merchant.com.np/page/esewa_payment_failed?q=fu" type="hidden" name="fu">
                            <img src="./themes/images/esewa.png" style="width: 100%;" alt="">
                            <input class="btn btn-success w-100" value="Pay With eSewa" type="submit">
                        </form>
                    <?php } ?>
                <?php } ?>
            </div>
            <div class="col">
            <img src="./themes/images/paypal-logo.png" style="width: 100%;" alt="">
            <form action="" class="mt-2">
            <input class="btn btn-success w-100" value="Pay With PayPal" type="submit" disabled>
            </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>