<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Show Products</title>
</head>

<body>

    <div class="container text-center" style="margin-top:100px;">
        <div class="container text-center">
            <div class="row">
                <div class="col">
                </div>
                <div class="col">
                <h1 class="mb-5">Products</h1>
                </div>
                <div class="col">
                <a href="http://localhost/e-commerce-site/bootstrap-shop/admin/index.php"><input class="btn btn-large btn-success float-end" name="submit_data" value="Back" /></a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">

            </div>
            <div class="col-12">
                <table class="table">
                    <thead>
                        <tr>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Title</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Price</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Brand</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Model</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Category</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Description</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Features</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Image</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col">Product Registered Date</th>
                            <th style="background-color: black; color:white; border-right:1px solid white;" scope="col" colspan="2">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include "./DB_CON/config.php";

                        $sql = "SELECT * FROM `product_data` ORDER BY id DESC";
                        $result = mysqli_query($conn, $sql) or die("ERROR: MySQL Query Failed to Execute!!");

                        if (mysqli_num_rows($result) > 0) {
                        ?>
                            <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                                <tr>
                                    <td style="background-color: lightgray; color:red; border-right:1px solid black; border-bottom:1px solid black;"><b><?php echo $row['product_title']; ?></b></td>
                                    <td style="background-color: lightgray; color:green; border-right:1px solid black; border-bottom:1px solid black;"><b>Rs <?php echo $row['product_price']; ?></b></td>
                                    <td style="background-color: lightgray; color:black; border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_brand']; ?></td>
                                    <td style="background-color: lightgray; color:black; border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_model']; ?></td>
                                    <td style="background-color: lightgray; color:black; border-right:1px solid black; border-bottom:1px solid black;"><?php
                                                                                            if ($row['product_category'] == null) {
                                                                                                echo "-";
                                                                                            } else {
                                                                                                echo $row['product_category'];
                                                                                            }
                                                                                            ?></td>
                                    <td style="background-color: lightgray; color:black;border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_description']; ?></td>
                                    <td style="background-color: lightgray; color:black;border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_features']; ?></td>
                                    <td style="background-color: lightgray; color:black;border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_image']; ?></td>
                                    <td style="background-color: lightgray; color:black;border-right:1px solid black; border-bottom:1px solid black;"><?php echo $row['product_date']; ?></td>
                                    <td style="background-color: lightgray; color:black; padding:30px;border-right:1px solid black; border-bottom:1px solid black;"><a href="edit.php" style="background-color: green; color:white; padding:10px; text-decoration:none;">Edit</a></td>
                                    <td style="background-color: lightgray; color:black; padding:30px; border-bottom:1px solid black;"><a href="delete.php?id=<?php echo $row['id']; ?>"  style="background-color: red; color:white; padding:10px; text-decoration:none;">Delete</a></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <div class="col">

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>