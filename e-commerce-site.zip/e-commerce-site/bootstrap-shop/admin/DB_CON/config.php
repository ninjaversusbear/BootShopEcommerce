<?php 

    $conn = mysqli_connect("localhost","root", "","bootshop_db") or die("ERROR: Connection to MySQL Database Failed!!" . mysqli_connect_error());
?>