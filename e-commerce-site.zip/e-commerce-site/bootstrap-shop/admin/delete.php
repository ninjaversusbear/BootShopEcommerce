<?php 
    include "./DB_CON/config.php";

    $id = $_GET['id'];

    $sql = "DELETE FROM `product_data` WHERE id = '{$id}'";
    $result = mysqli_query($conn, $sql) or die("ERROR: MySQL Query Failed to Execute!!");

    if($result){
        header("Location: http://localhost/e-commerce-site/bootstrap-shop/admin/show_products.php");
    }else{
        echo "<script>alert('Product Not Deleted!!');</script>";
    }
?>