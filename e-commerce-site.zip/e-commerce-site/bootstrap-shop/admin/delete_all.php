<?php 

    if(isset($_POST['delete_all_records'])){

        include "./DB_CON/config.php";

        $sql = "DELETE FROM `product_data`";
        $result = mysqli_query($conn, $sql) or die("ERROR: Failed to Delete all the Records from Database!!");

        if($result){
            header("location: http://localhost/e-commerce-site/bootstrap-shop/admin/show_products.php");
        }else{
            echo "<script>
            alert('Records Failed to Delete!!');
            </script>";
        }
    }

?>